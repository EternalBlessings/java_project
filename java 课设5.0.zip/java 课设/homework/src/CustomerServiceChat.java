import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 一对一客服聊天窗口
 * 实现用户与客服的实时聊天功能
 */
public class CustomerServiceChat extends JFrame {

    // 当前用户信息
    private final int userId;
    private final String username;

    // UI组件
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;

    // 消息格式
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

    // 客服名称
    private static final String SERVICE_NAME = "客服小助手";

    // 客服回复库
    private static final String[] SERVICE_REPLIES = {
            "您好，请问有什么可以帮您？",
            "感谢您的咨询，我们会尽快处理您的问题。",
            "请提供更多详细信息，以便我们更好地帮助您。",
            "您的反馈对我们非常重要，谢谢！",
            "请问您的问题是否已经解决？",
            "我们非常重视您的体验，如有更多问题，请随时联系我们。",
            "请稍等，正在为您查询...",
            "根据您描述的情况，建议您尝试重新启动设备。",
            "非常抱歉给您带来不便，我们会尽快解决该问题。",
            "感谢您的理解和支持！"
    };

    public CustomerServiceChat(int userId, String username) {
        super("客服聊天 - " + username);
        this.userId = userId;
        this.username = username;

        // 设置窗口属性
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 设置UI样式，保持与主系统一致
        getContentPane().setBackground(new Color(240, 242, 245));

        // 创建聊天区域
        createChatArea();

        // 创建输入面板
        createInputPanel();

        // 添加欢迎消息
        addSystemMessage("欢迎使用客服系统！客服代表将很快为您服务");
        addServiceMessage(SERVICE_REPLIES[0]); // 初始问候
    }

    /**
     * 创建聊天显示区域
     */
    private void createChatArea() {
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        chatArea.setBackground(new Color(250, 250, 250));
        chatArea.setMargin(new Insets(10, 10, 10, 10));

        // 使用滚动面板包装
        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("聊天记录"));
        add(scrollPane, BorderLayout.CENTER);
    }

    /**
     * 创建输入面板
     */
    private void createInputPanel() {
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        inputPanel.setBackground(Color.WHITE);

        // 输入框
        inputField = new JTextField();
        inputField.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        inputField.addActionListener(e -> sendMessage()); // 支持回车发送
        inputPanel.add(inputField, BorderLayout.CENTER);

        // 发送按钮
        sendButton = new JButton("发送");
        sendButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
        sendButton.setBackground(new Color(50, 150, 200));
        sendButton.setForeground(Color.WHITE);
        sendButton.setFocusPainted(false);
        sendButton.setPreferredSize(new Dimension(80, 30));
        sendButton.addActionListener(e -> sendMessage());
        inputPanel.add(sendButton, BorderLayout.EAST);

        add(inputPanel, BorderLayout.SOUTH);
    }

    /**
     * 发送用户消息
     */
    private void sendMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty()) {
            // 添加用户消息到聊天区域
            addUserMessage(message);
            inputField.setText("");

            // 模拟客服回复（延迟1-3秒）
            simulateServiceReply();
        }
    }

    /**
     * 模拟客服回复
     */
    private void simulateServiceReply() {
        // 使用定时器模拟客服思考时间
        Timer replyTimer = new Timer(1000 + (int)(Math.random() * 2000), e -> {
            // 随机选择一条回复
            int replyIndex = (int)(Math.random() * SERVICE_REPLIES.length);
            addServiceMessage(SERVICE_REPLIES[replyIndex]);
        });
        replyTimer.setRepeats(false);
        replyTimer.start();
    }

    /**
     * 添加用户消息到聊天区域
     * @param message 用户消息内容
     */
    private void addUserMessage(String message) {
        String time = timeFormat.format(new Date());
        chatArea.append("[" + time + "] " + username + ":\n");
        chatArea.append("  " + message + "\n\n");
        autoScroll();
    }

    /**
     * 添加客服消息到聊天区域
     * @param message 客服消息内容
     */
    private void addServiceMessage(String message) {
        String time = timeFormat.format(new Date());
        chatArea.append("[" + time + "] " + SERVICE_NAME + ":\n");
        chatArea.append("  " + message + "\n\n");
        autoScroll();
    }

    /**
     * 添加系统消息到聊天区域
     * @param message 系统消息内容
     */
    private void addSystemMessage(String message) {
        String time = timeFormat.format(new Date());
        chatArea.append("[" + time + "] 系统提示:\n");
        chatArea.append("  " + message + "\n\n");
        autoScroll();
    }

    /**
     * 自动滚动到最新消息
     */
    private void autoScroll() {
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }
}



