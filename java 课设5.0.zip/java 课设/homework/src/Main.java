import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // 在Swing事件调度线程中启动登录界面
        SwingUtilities.invokeLater(() -> {
            new AdminLoginFrame();
        });
    }
}