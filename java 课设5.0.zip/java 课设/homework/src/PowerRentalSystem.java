import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
//用户操作系统
//采用MVC模式使界面设计与业务逻辑分离

//初始化
public class PowerRentalSystem extends JFrame {

    // 数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/power_rental_db?useSSL=false";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "yangpl1689";
    // 当前用户信息
    private int currentUserId = -1;
    private String currentUsername = "";
    private boolean isAdmin = false;
    private double currentBalance = 0.0;
    // UI组件
    private JTabbedPane tabbedPane;
    private JTable powerBankTable;
    private JTable orderTable;
    private JLabel balanceLabel;
    private JLabel rentalStatusLabel;
    private Timer rentalTimer;
    private long rentalStartTime;
    private int currentRentalPowerBankId = -1;
    // 数据库连接
    private Connection conn;

    public PowerRentalSystem() {
        super("移动电源租赁系统");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 初始化数据库连接
        initDatabase();

        // 创建主界面
        createMainUI();

        // 加载数据
        loadPowerBanks();
        loadUserOrders();
        updateUserInfo();

        setVisible(true);
    }

    private void initDatabase() {
        try {
            // 加载JDBC驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 创建数据库连接
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // 创建表（如果不存在）
            createTablesIfNotExists();

            // 插入初始数据
            insertInitialData();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "数据库连接失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void createTablesIfNotExists() throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            // 创建用户表
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "username VARCHAR(50) UNIQUE NOT NULL, " +
                    "password VARCHAR(50) NOT NULL, " +
                    "phone VARCHAR(20) NOT NULL, " +
                    "balance DECIMAL(10,2) DEFAULT 100.00, " +
                    "is_admin BOOLEAN DEFAULT FALSE, " +
                    "gender VARCHAR(10) NOT NULL)");

            // 创建移动电源表
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS power_banks (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "model VARCHAR(50) NOT NULL, " +
                    "battery_level INT NOT NULL, " +
                    "status ENUM('AVAILABLE', 'RENTED', 'UNAVAILABLE') DEFAULT 'AVAILABLE', " +
                    "location VARCHAR(100) NOT NULL)");

            // 创建订单表
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS orders (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "user_id INT NOT NULL, " +
                    "power_bank_id INT NOT NULL, " +
                    "start_time DATETIME NOT NULL, " +
                    "end_time DATETIME, " +
                    "duration_minutes INT, " +
                    "total_cost DECIMAL(10,2), " +
                    "FOREIGN KEY (user_id) REFERENCES users(id), " +
                    "FOREIGN KEY (power_bank_id) REFERENCES power_banks(id))");
        }
    }

    private void insertInitialData() throws SQLException {
        // 检查用户表是否为空
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users")) {

            if (rs.next() && rs.getInt(1) == 0) {
                // 插入用户数据
                stmt.executeUpdate("INSERT INTO users (username, password, phone, balance, is_admin) VALUES " +
                        "('admin', 'admin123', '13800138000', 500.00, TRUE), " +
                        "('user1', 'pass1234', '13912345678', 200.00, FALSE), " +
                        "('user2', 'pass5678', '15098765432', 150.00, FALSE)");

                // 插入电源数据
                stmt.executeUpdate("INSERT INTO power_banks (model, battery_level, status, location) VALUES " +
                        "('Mi Power Pro', 80, 'AVAILABLE', 'A区充电柜-01'), " +
                        "('Anker 10000mAh', 65, 'AVAILABLE', 'B区充电柜-03'), " +
                        "('Romoss Sense 8', 45, 'UNAVAILABLE', 'C区充电柜-02'), " + // 电量不足
                        "('Baseus Mini', 95, 'AVAILABLE', 'D区充电柜-04'), " +
                        "('Huawei SuperCharge', 70, 'RENTED', 'E区充电柜-05'), " + // 已被租赁
                        "('Samsung Wireless', 60, 'AVAILABLE', 'F区充电柜-06')");

                // 插入订单数据
                stmt.executeUpdate("INSERT INTO orders (user_id, power_bank_id, start_time, end_time, duration_minutes, total_cost) VALUES " +
                        "(2, 1, '2023-10-01 10:30:00', '2023-10-01 12:45:00', 135, 3.38), " +
                        "(2, 4, '2023-10-02 15:20:00', '2023-10-02 18:30:00', 190, 4.75), " +
                        "(3, 2, '2023-10-03 09:15:00', '2023-10-03 11:30:00', 135, 3.38), " +
                        "(3, 6, '2023-10-04 14:00:00', NULL, NULL, NULL)"); // 未归还订单

                JOptionPane.showMessageDialog(this, "数据库已初始化，插入测试数据！", "系统提示", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    //操作面板
    private void createMainUI() {
        // 创建主面板
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 242, 245));

        // 创建顶部工具栏
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(new Color(70, 130, 180));

        // 用户信息标签
        JLabel userInfoLabel = new JLabel("用户: " + currentUsername);
        userInfoLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        userInfoLabel.setForeground(Color.WHITE);
        toolBar.add(userInfoLabel);

        toolBar.add(Box.createHorizontalStrut(20));

        // 余额标签
        balanceLabel = new JLabel("余额: ￥" + String.format("%.2f", currentBalance));
        balanceLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        balanceLabel.setForeground(Color.WHITE);
        toolBar.add(balanceLabel);

        toolBar.add(Box.createHorizontalStrut(20));

        // 租赁状态标签
        rentalStatusLabel = new JLabel("租赁状态: 未租赁");
        rentalStatusLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        rentalStatusLabel.setForeground(Color.WHITE);
        toolBar.add(rentalStatusLabel);

        // 添加空白区域使右侧按钮靠右
        toolBar.add(Box.createHorizontalGlue());

        // 个人信息按钮
        JButton profileButton = new JButton("个人信息");
        profileButton.setBackground(new Color(50, 150, 200));
        profileButton.setForeground(Color.WHITE);
        profileButton.setFocusPainted(false);
        profileButton.addActionListener(e -> showProfileDialog());
        toolBar.add(profileButton);

        toolBar.add(Box.createHorizontalStrut(10));

        // ... 个人信息按钮代码之后
        toolBar.add(Box.createHorizontalStrut(10));
// 新增客服按钮
        JButton serviceButton = new JButton("联系客服");
        serviceButton.setBackground(new Color(255, 165, 0)); // 橙色
        serviceButton.setForeground(Color.WHITE);
        serviceButton.setFocusPainted(false);
        serviceButton.addActionListener(e -> openCustomerServiceChat());
        toolBar.add(serviceButton);

        toolBar.add(Box.createHorizontalStrut(10)); // 与退出按钮的间隔

// ... 退出登录按钮代码

        // 退出登录按钮
        JButton logoutButton = new JButton("退出登录");
        logoutButton.setBackground(new Color(192, 57, 43));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.addActionListener(e -> logout());
        toolBar.add(logoutButton);

        mainPanel.add(toolBar, BorderLayout.NORTH);

        // 创建选项卡面板
        tabbedPane = new JTabbedPane();

        // 电源租赁面板
        JPanel rentalPanel = createRentalPanel();
        tabbedPane.addTab("电源租赁", new ImageIcon(), rentalPanel);

        // 我的订单面板
        JPanel ordersPanel = createOrdersPanel();
        tabbedPane.addTab("我的订单", new ImageIcon(), ordersPanel);


        if (isAdmin) {
            JPanel adminPanel = createAdminPanel();
            tabbedPane.addTab("系统管理", new ImageIcon(), adminPanel);
        }

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // 底部状态栏+时间
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.setBorder(BorderFactory.createEtchedBorder());
        statusPanel.setBackground(new Color(230, 230, 230));
        JLabel statusLabel = new JLabel("系统状态: 运行中 | 当前时间: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        statusPanel.add(statusLabel);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createRentalPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // 标题
        JLabel titleLabel = new JLabel("可用移动电源列表 (电量 > 50%)", SwingConstants.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        panel.add(titleLabel, BorderLayout.NORTH);

        // 创建电源表格
        String[] columnNames = {"ID", "型号", "电量", "状态", "位置"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 表格不可编辑
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) return Integer.class;
                return String.class;
            }
        };
        powerBankTable = new JTable(model);
        powerBankTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        powerBankTable.setRowHeight(35);
        powerBankTable.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        powerBankTable.getTableHeader().setFont(new Font("微软雅黑", Font.BOLD, 14));

        // 添加表格到滚动面板
        JScrollPane scrollPane = new JScrollPane(powerBankTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panel.add(scrollPane, BorderLayout.CENTER);

        // 创建底部按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        // 租赁按钮
        JButton rentButton = new JButton("租赁电源");
        rentButton.setFont(new Font("微软雅黑", Font.BOLD, 16));
        rentButton.setPreferredSize(new Dimension(150, 40));
        rentButton.setBackground(new Color(76, 175, 80));
        rentButton.setForeground(Color.WHITE);
        rentButton.addActionListener(e -> rentPowerBank());
        buttonPanel.add(rentButton);

        // 归还按钮
        JButton returnButton = new JButton("归还电源");
        returnButton.setFont(new Font("微软雅黑", Font.BOLD, 16));
        returnButton.setPreferredSize(new Dimension(150, 40));
        returnButton.setBackground(new Color(231, 76, 60));
        returnButton.setForeground(Color.WHITE);
        returnButton.addActionListener(e -> returnPowerBank());
        buttonPanel.add(returnButton);

        // 刷新按钮
        JButton refreshButton = new JButton("刷新列表");
        refreshButton.setFont(new Font("微软雅黑", Font.BOLD, 16));
        refreshButton.setPreferredSize(new Dimension(150, 40));
        refreshButton.setBackground(new Color(52, 152, 219));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(e -> loadPowerBanks());
        buttonPanel.add(refreshButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createOrdersPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // 标题
        JLabel titleLabel = new JLabel("我的租赁订单", SwingConstants.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        panel.add(titleLabel, BorderLayout.NORTH);

        // 创建订单表格
        String[] columnNames = {"订单ID", "电源ID", "开始时间", "结束时间", "时长(分钟)", "费用(元)"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 表格不可编辑
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0 || columnIndex == 1 || columnIndex == 4) return Integer.class;
                if (columnIndex == 5) return Double.class;
                return String.class;
            }
        };
        orderTable = new JTable(model);
        orderTable.setRowHeight(35);
        orderTable.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        orderTable.getTableHeader().setFont(new Font("微软雅黑", Font.BOLD, 14));

        // 添加表格到滚动面板
        JScrollPane scrollPane = new JScrollPane(orderTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panel.add(scrollPane, BorderLayout.CENTER);

        // 创建底部按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        // 刷新按钮
        JButton refreshButton = new JButton("刷新订单");
        refreshButton.setFont(new Font("微软雅黑", Font.BOLD, 16));
        refreshButton.setPreferredSize(new Dimension(150, 40));
        refreshButton.setBackground(new Color(52, 152, 219));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(e -> loadUserOrders());
        buttonPanel.add(refreshButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createAdminPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // 创建管理员面板内容
        JLabel titleLabel = new JLabel("管理员控制面板", SwingConstants.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 24));
        titleLabel.setForeground(new Color(50, 65, 85));
        panel.add(titleLabel, BorderLayout.NORTH);

        // 添加管理功能按钮
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(40, 100, 40, 100));

        String[] adminFunctions = {"用户管理", "电源管理", "订单管理", "数据统计"};
        Color[] buttonColors = {
                new Color(52, 152, 219),
                new Color(46, 204, 113),
                new Color(155, 89, 182),
                new Color(241, 196, 15)
        };

        for (int i = 0; i < adminFunctions.length; i++) {
            final String functionName = adminFunctions[i]; // 创建一个final局部变量
            JButton button = new JButton(adminFunctions[i]);
            button.setFont(new Font("微软雅黑", Font.BOLD, 18));
            button.setBackground(buttonColors[i]);
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false);
            button.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));

            button.addActionListener(e -> {
                JOptionPane.showMessageDialog(this, functionName + "功能尚未实现", "提示", JOptionPane.INFORMATION_MESSAGE);
            });
            buttonPanel.add(button);
        }

        panel.add(buttonPanel, BorderLayout.CENTER);

        return panel;
    }
//订单管理模块:
// 查看历史订单
//    显示租赁时长和费用
//    刷新订单列表
    private void loadPowerBanks() {
        try {
            // 获取可用电源（电量>50%且状态为可用）
            String sql = "SELECT id, model, battery_level, status, location FROM power_banks " +
                    "WHERE battery_level > 50 AND status = 'AVAILABLE'";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();

                // 清空表格
                DefaultTableModel model = (DefaultTableModel) powerBankTable.getModel();
                model.setRowCount(0);

                // 填充表格
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String modelName = rs.getString("model");
                    int battery = rs.getInt("battery_level");
                    String status = rs.getString("status");
                    String location = rs.getString("location");

                    model.addRow(new Object[]{id, modelName, battery + "%", status, location});
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "加载电源数据失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }
//    用户信息管理模块功能：
//    查看个人信息
//    修改手机号
//    修改密码
//    查看余额
    private void loadUserOrders() {
        try {
            String sql = "SELECT id, power_bank_id, start_time, end_time, duration_minutes, total_cost " +
                    "FROM orders WHERE user_id = ? ORDER BY start_time DESC";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, currentUserId);
                ResultSet rs = pstmt.executeQuery();

                // 清空表格
                DefaultTableModel model = (DefaultTableModel) orderTable.getModel();
                model.setRowCount(0);

                // 填充表格
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                while (rs.next()) {
                    int id = rs.getInt("id");
                    int powerBankId = rs.getInt("power_bank_id");
                    Date startTime = rs.getTimestamp("start_time");
                    Date endTime = rs.getTimestamp("end_time");
                    int duration = rs.getInt("duration_minutes");
                    double cost = rs.getDouble("total_cost");

                    String startStr = startTime != null ? sdf.format(startTime) : "";
                    String endStr = endTime != null ? sdf.format(endTime) : "";

                    model.addRow(new Object[]{
                            id,
                            powerBankId,
                            startStr,
                            endStr,
                            duration,
                            String.format("%.2f", cost)
                    });
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "加载订单数据失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateUserInfo() {
        try {
            String sql = "SELECT username, balance FROM users WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, currentUserId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    currentUsername = rs.getString("username");
                    currentBalance = rs.getDouble("balance");
                    balanceLabel.setText("余额: ￥" + String.format("%.2f", currentBalance));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "获取用户信息失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void rentPowerBank() {
        int selectedRow = powerBankTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "请先选择一个电源", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int powerBankId = (Integer) powerBankTable.getValueAt(selectedRow, 0);

        try {
            // 检查电源是否可用
            String checkSql = "SELECT status FROM power_banks WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
                pstmt.setInt(1, powerBankId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    String status = rs.getString("status");
                    if (!"AVAILABLE".equals(status)) {
                        JOptionPane.showMessageDialog(this, "该电源当前不可用", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // 开始事务
            conn.setAutoCommit(false);

            // 更新电源状态
            String updatePowerSql = "UPDATE power_banks SET status = 'RENTED' WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updatePowerSql)) {
                pstmt.setInt(1, powerBankId);
                pstmt.executeUpdate();
            }

            // 创建新订单
            String insertOrderSql = "INSERT INTO orders (user_id, power_bank_id, start_time) VALUES (?, ?, NOW())";
            try (PreparedStatement pstmt = conn.prepareStatement(insertOrderSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setInt(1, currentUserId);
                pstmt.setInt(2, powerBankId);
                pstmt.executeUpdate();

                // 获取生成的订单ID
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    int orderId = rs.getInt(1);

                    // 提交事务
                    conn.commit();

                    // 更新UI状态
                    currentRentalPowerBankId = powerBankId;
                    rentalStartTime = System.currentTimeMillis();
                    rentalStatusLabel.setText("租赁中: 电源#" + powerBankId);

                    // 启动计时器
                    startRentalTimer();

                    // 刷新列表
                    loadPowerBanks();

                    JOptionPane.showMessageDialog(this, "租赁成功！电源#" + powerBankId, "成功", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "租赁失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
//租赁计时器
    private void startRentalTimer() {
        if (rentalTimer != null) {
            rentalTimer.cancel();
        }

        rentalTimer = new Timer();
        rentalTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                // 更新租赁状态
                long elapsedSeconds = (System.currentTimeMillis() - rentalStartTime) / 1000;
                long minutes = elapsedSeconds / 60;
                long seconds = elapsedSeconds % 60;

                SwingUtilities.invokeLater(() -> {
                    rentalStatusLabel.setText(String.format("租赁中: 电源#%d (%02d:%02d)",
                            currentRentalPowerBankId, minutes, seconds));
                });
            }
        }, 0, 1000); // 每秒更新一次
    }

    private void returnPowerBank() {
        if (currentRentalPowerBankId == -1) {
            JOptionPane.showMessageDialog(this, "您当前没有租赁任何电源", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // 结束计时
            if (rentalTimer != null) {
                rentalTimer.cancel();
                rentalTimer = null;
            }

            // 计算租赁时长和费用
            long rentalDuration = (System.currentTimeMillis() - rentalStartTime) / 1000 / 60; // 分钟
            double cost = rentalDuration * 1.5 / 60; // 每分钟0.025元

            // 开始事务
            conn.setAutoCommit(false);

            // 更新电源状态（假设归还后电量为随机值）
            int newBatteryLevel = (int) (Math.random() * 50) + 20; // 20-70%
            String updatePowerSql = "UPDATE power_banks SET status = ?, battery_level = ? WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updatePowerSql)) {
                String status = newBatteryLevel > 50 ? "AVAILABLE" : "UNAVAILABLE";
                pstmt.setString(1, status);
                pstmt.setInt(2, newBatteryLevel);
                pstmt.setInt(3, currentRentalPowerBankId);
                pstmt.executeUpdate();
            }

            // 更新订单信息
            String updateOrderSql = "UPDATE orders SET end_time = NOW(), duration_minutes = ?, total_cost = ? " +
                    "WHERE user_id = ? AND power_bank_id = ? AND end_time IS NULL";
            try (PreparedStatement pstmt = conn.prepareStatement(updateOrderSql)) {
                pstmt.setLong(1, rentalDuration);
                pstmt.setDouble(2, cost);
                pstmt.setInt(3, currentUserId);
                pstmt.setInt(4, currentRentalPowerBankId);
                pstmt.executeUpdate();
            }

            // 更新用户余额
            String updateUserSql = "UPDATE users SET balance = balance - ? WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updateUserSql)) {
                pstmt.setDouble(1, cost);
                pstmt.setInt(2, currentUserId);
                pstmt.executeUpdate();
            }

            // 提交事务
            conn.commit();

            // 更新UI状态
            currentRentalPowerBankId = -1;
            rentalStatusLabel.setText("租赁状态: 未租赁");

            // 刷新数据
            updateUserInfo();
            loadPowerBanks();
            loadUserOrders();

            JOptionPane.showMessageDialog(this,
                    String.format("归还成功！租赁时长: %d分钟，费用: ￥%.2f", rentalDuration, cost),
                    "成功", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "归还失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void showProfileDialog() {
        JDialog dialog = new JDialog(this, "个人信息", true);
        dialog.setSize(400, 350);
        dialog.setLayout(new GridBagLayout());
        dialog.setLocationRelativeTo(this);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 标题
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("个人信息管理", SwingConstants.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        dialog.add(titleLabel, gbc);

        // 分隔线
        gbc.gridy = 1;
        JSeparator separator = new JSeparator();
        dialog.add(separator, gbc);

        // 获取用户信息
        String phone = "";
        try {
            String sql = "SELECT phone, balance FROM users WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, currentUserId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    phone = rs.getString("phone");
                    currentBalance = rs.getDouble("balance");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(dialog, "获取用户信息失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 用户名
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        dialog.add(new JLabel("用户名:"), gbc);

        gbc.gridx = 1;
        JTextField usernameField = new JTextField(currentUsername);
        usernameField.setEditable(false);
        dialog.add(usernameField, gbc);

        // 手机号
        gbc.gridy = 3;
        gbc.gridx = 0;
        dialog.add(new JLabel("手机号:"), gbc);

        gbc.gridx = 1;
        JTextField phoneField = new JTextField(phone);
        dialog.add(phoneField, gbc);

        // 余额
        gbc.gridy = 4;
        gbc.gridx = 0;
        dialog.add(new JLabel("余额:"), gbc);

        gbc.gridx = 1;
        JTextField balanceField = new JTextField("￥" + String.format("%.2f", currentBalance));
        balanceField.setEditable(false);
        dialog.add(balanceField, gbc);

        // 新密码
        gbc.gridy = 5;
        gbc.gridx = 0;
        dialog.add(new JLabel("新密码:"), gbc);

        gbc.gridx = 1;
        JPasswordField newPasswordField = new JPasswordField();
        dialog.add(newPasswordField, gbc);

        // 确认密码
        gbc.gridy = 6;
        gbc.gridx = 0;
        dialog.add(new JLabel("确认密码:"), gbc);

        gbc.gridx = 1;
        JPasswordField confirmPasswordField = new JPasswordField();
        dialog.add(confirmPasswordField, gbc);

        // 按钮面板
        gbc.gridy = 7;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        //用户个人信息修改
        JButton saveButton = new JButton("保存修改");
        saveButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
        saveButton.setPreferredSize(new Dimension(120, 35));
        saveButton.setBackground(new Color(76, 175, 80));
        saveButton.setForeground(Color.WHITE);
        saveButton.addActionListener(e -> {
            String newPhone = phoneField.getText();
            String newPassword = new String(newPasswordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());

            // 验证手机号
            if (!newPhone.matches("^1[3-9]\\d{9}$")) {
                JOptionPane.showMessageDialog(dialog, "请输入有效的手机号码", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 验证密码
            if (!newPassword.isEmpty() && !newPassword.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(dialog, "两次输入的密码不一致", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 更新用户信息
            try {
                if (newPassword.isEmpty()) {
                    // 只更新手机号
                    String sql = "UPDATE users SET phone = ? WHERE id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, newPhone);
                        pstmt.setInt(2, currentUserId);
                        pstmt.executeUpdate();
                    }
                } else {
                    // 更新手机号和密码
                    String sql = "UPDATE users SET phone = ?, password = ? WHERE id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, newPhone);
                        pstmt.setString(2, newPassword);
                        pstmt.setInt(3, currentUserId);
                        pstmt.executeUpdate();
                    }
                }

                JOptionPane.showMessageDialog(dialog, "个人信息更新成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "更新失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        });
        buttonPanel.add(saveButton);

        JButton cancelButton = new JButton("取消");
        cancelButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
        cancelButton.setPreferredSize(new Dimension(120, 35));
        cancelButton.setBackground(new Color(120, 120, 120));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(cancelButton);

        dialog.add(buttonPanel, gbc);

        dialog.setVisible(true);
    }

    private void logout() {
        // 停止计时器
        if (rentalTimer != null) {
            rentalTimer.cancel();
        }

        // 关闭数据库连接
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // 返回登录界面
        dispose();
        new LoginPage(this).setVisible(true);
    }

    public void setCurrentUser(int userId, String username, boolean isAdmin) {
        this.currentUserId = userId;
        this.currentUsername = username;
        this.isAdmin = isAdmin;
        updateUserInfo();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // 显示登录对话框
            new LoginPage(null).setVisible(true);
        });
    }
    private void openCustomerServiceChat() {
        // 创建客服聊天窗口，传入当前用户信息
        CustomerServiceChat chatWindow = new CustomerServiceChat(currentUserId, currentUsername);
        chatWindow.setVisible(true);
    }
}