import javax.swing.*;
import java.awt.*;
import java.sql.*;
public class AdminLoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public AdminLoginFrame() {
        setTitle("管理员登录");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
        setVisible(true);
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("管理员登录系统", JLabel.CENTER);
        titleLabel.setFont(new Font("宋体", Font.BOLD, 20));
        panel.add(titleLabel, gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(new JLabel("用户名:"), gbc);
        gbc.gridx = 1;
        usernameField = new JTextField(20);
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("密码:"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JButton loginButton = new JButton("登录");
        loginButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (validateAdmin(username, password)) {
                new AdminMainFrame();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "用户名正确",
                        "登录成功",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(loginButton, gbc);

        add(panel);
    }

    private boolean validateAdmin(String username, String password) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean valid = false;

        try {
            conn = DatabaseUtil.getConnection();
            if (conn != null) {
                String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                rs = pstmt.executeQuery();
                valid = rs.next();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "数据库连接错误，请联系管理员",
                    "系统错误",
                    JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseUtil.close(conn, pstmt, rs);
        }

        return valid;
    }
}