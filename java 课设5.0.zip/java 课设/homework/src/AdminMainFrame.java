import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
// 引入表格模型库
import javax.swing.table.DefaultTableModel;

// 定义管理员主界面类
public class AdminMainFrame extends JFrame {
    private DefaultTableModel powerBankModel;
    private DefaultTableModel userModel;
    // 数据库连接对象
    private Connection conn;
    // 显示充电宝信息的表格组件
    private JTable tablePowerBank;
    private JTable tableUser;
    // 窗口初始化
    public AdminMainFrame() {
        setTitle("管理员管理系统");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 界面元素
        Container container = getContentPane();
        // 分成东、南、西、北、中
        container.setLayout(new BorderLayout());
        JPanel panelPowerBank = createManagementPanel("充电宝管理",
                new String[]{"ID", "电量", "状态", "位置"});
        container.add(panelPowerBank, BorderLayout.WEST);
        JPanel panelUser = createManagementPanel("用户管理",
                new String[]{"用户ID", "密码", "姓名", "手机号", "订单历史"});
        container.add(panelUser, BorderLayout.EAST);

        // 连接数据库
        conn = DatabaseUtil.getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "数据库连接失败", "错误", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        // 从数据库加载充电宝和用户数据
        loadPowerBanks();
        loadUsers();
        setVisible(true);
    }



    // 创建管理面板
    private JPanel createManagementPanel(String title, String[] columns) {
        JPanel panel = new JPanel(new BorderLayout());
        // 给面板加一个标题，比如"充电宝管理"
        panel.setBorder(BorderFactory.createTitledBorder(title));

        // 充电宝/用户面板，创建表格
        if (title.equals("充电宝管理")) {
            // 创建空的表格模型，列名是传入的columns
            powerBankModel = new DefaultTableModel(columns, 0);
            // 创建表格组件
            tablePowerBank = new JTable(powerBankModel);
            // 给表格加滚动条，放在面板中间
            panel.add(new JScrollPane(tablePowerBank), BorderLayout.CENTER);
        } else {
            userModel = new DefaultTableModel(columns, 0);
            tableUser = new JTable(userModel);
            panel.add(new JScrollPane(tableUser), BorderLayout.CENTER);
        }

        // 创建放按钮的面板
        JPanel buttons = new JPanel();
        if (title.equals("充电宝管理")) {
            // 添加按钮并绑定点击事件
            addButton(buttons, "新增充电宝", e -> addPowerBank());
            addButton(buttons, "删除充电宝", e -> deletePowerBank(tablePowerBank));
            addButton(buttons, "更新状态", e -> updatePowerBankStatus(tablePowerBank));
            addButton(buttons, "刷新数据", e -> loadPowerBanks());
        } else {
            addButton(buttons, "新增用户", e -> addUser());
            addButton(buttons, "删除用户", e -> deleteUser(tableUser));
            addButton(buttons, "修改信息", e -> updateUserInfo(tableUser));
            addButton(buttons, "刷新数据", e -> loadUsers());
        }
        // 把按钮放在面板底部
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    // 创建按钮
    private void addButton(JPanel panel, String text, ActionListener listener) {
        // 创建按钮文字
        JButton button = new JButton(text);
        button.addActionListener(listener);
        // 把按钮添加到面板上
        panel.add(button);
    }

    // 数据库获取充电宝数据
    private void loadPowerBanks() {
        try {
            String sql = "SELECT * FROM power_banks";
            // 预编译SQL语句，防止SQL注入攻击
            PreparedStatement pstmt = conn.prepareStatement(sql);
            // 执行查询
            ResultSet rs = pstmt.executeQuery();
            powerBankModel.setRowCount(0);

            // 遍历查询结果
            while (rs.next()) {
                powerBankModel.addRow(new Object[]{
                        rs.getString("id"),
                        rs.getDouble("battery"),     // 电量
                        rs.getString("status"),      // 状态（可用/借出等）
                        rs.getString("location")     // 存放位置
                });
            }
            // 关闭结果集和SQL语句
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            // 打印错误信息到控制台
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "加载充电宝数据失败", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 从数据库获取用户数据
    private void loadUsers() {
        try {
            String sql = "SELECT * FROM users";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            userModel.setRowCount(0);

            while (rs.next()) {
                userModel.addRow(new Object[]{
                        rs.getString("id"),
                        rs.getString("password"),   // 密码
                        rs.getString("username"),
                        rs.getString("phone"),
                        rs.getString("order_history") // 订单历史
                });
            }
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "加载用户数据失败", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 新增充电宝功能
    private void addPowerBank() {
        String id = JOptionPane.showInputDialog(this, "请输入充电宝ID：");
        if (id == null || id.trim().isEmpty()) return;
        // 用户输入电量
        double battery = getValidNumber("请输入电量（0-100）：", 0, 100);
        if (battery < 0) return;

        // 用户从下拉框选择状态（可用、借出、维修中）
        String status = (String) JOptionPane.showInputDialog(this, "请选择状态：", "状态选择",
                JOptionPane.QUESTION_MESSAGE, null, new String[]{"可用", "借出", "维修中"}, "可用");
        if (status == null) return;
        String location = JOptionPane.showInputDialog(this, "请输入存放位置：", "未知");
        if (location == null) location = "未知";
        executeUpdate("INSERT INTO power_bank (id, battery, status, location) VALUES (?, ?, ?, ?)",
                id, battery, status, location);
    }

    // 验证用户输入的数字是否有效
    private double getValidNumber(String prompt, double min, double max) {
        // 获取用户输入
        String input = JOptionPane.showInputDialog(this, prompt);
        if (input == null || input.trim().isEmpty()) return -1;

        try {
            // 把输入转为数字
            double value = Double.parseDouble(input);
            if (value < min || value > max) {
                JOptionPane.showMessageDialog(this, "数值必须在" + min + "-" + max + "之间", "错误", JOptionPane.ERROR_MESSAGE);
                return -1;
            }
            return value; // 有效数字返回
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "请输入有效的数字", "错误", JOptionPane.ERROR_MESSAGE);
            return -1;
        }
    }

    // 处理数据库增删改操作（新增、删除、修改）
    private void executeUpdate(String sql, Object... params) {
        try {
            // 预编译SQL语句
            PreparedStatement pstmt = conn.prepareStatement(sql);
            // 给SQL中的?赋值，params是传入的参数（比如ID、电量等）
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }
            // 执行SQL语句，affected是影响的行数（成功时>=1）
            int affected = pstmt.executeUpdate();
            pstmt.close();

            if (affected > 0) { // 操作成功
                String successMsg = sql.contains("INSERT") ? "添加成功" : "更新成功";
                JOptionPane.showMessageDialog(this, sql.contains("user") ? "用户" : "充电宝" + successMsg,
                        "成功", JOptionPane.INFORMATION_MESSAGE);
                // 刷新对应表格数据（操作充电宝就刷新充电宝表格）
                if (sql.contains("power_bank")) loadPowerBanks();
                else loadUsers();
            } else {
                String errorMsg = sql.contains("INSERT") ? "添加失败，可能ID已存在" : "操作失败";
                JOptionPane.showMessageDialog(this, sql.contains("user") ? "用户" : "充电宝" + errorMsg,
                        "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "数据库操作失败：" + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 删除充电宝功能
    private void deletePowerBank(JTable table) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "请先选择要删除的充电宝", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // 获取选中行的充电宝ID
        String id = (String) table.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "确定要删除ID为 " + id + " 的充电宝吗？",
                "删除确认", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            // 执行删除SQL语句
            executeUpdate("DELETE FROM power_bank WHERE id = ?", id);
        }
    }

    // 更新充电宝状态功能
    private void updatePowerBankStatus(JTable table) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "请先选择要更新的充电宝", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = (String) table.getValueAt(row, 0);
        String currentStatus = (String) table.getValueAt(row, 2); // 获取当前状态

        // 弹出下拉框让用户选新状态，默认显示当前状态
        String newStatus = (String) JOptionPane.showInputDialog(this, "当前状态：" + currentStatus + "\n请选选择新状态：",
                "状态更新", JOptionPane.QUESTION_MESSAGE, null, new String[]{"可用", "借出", "维修中"}, currentStatus);
        if (newStatus == null || currentStatus.equals(newStatus)) return;

        // 执行更新状态的SQL语句
        executeUpdate("UPDATE power_bank SET status = ? WHERE id = ?", newStatus, id);
    }

    // 新增用户功能
    private void addUser() {
        String userId = JOptionPane.showInputDialog(this, "请输入用户ID：");
        if (userId == null || userId.trim().isEmpty()) return;

        String password = JOptionPane.showInputDialog(this, "请输入密码：");
        if (password == null || password.trim().isEmpty()) return;

        String name = JOptionPane.showInputDialog(this, "请输入姓名：");
        if (name == null || name.trim().isEmpty()) return;
        String phone = JOptionPane.showInputDialog(this, "请输入手机号（可选）：", "");
        if (phone == null) phone = "";

        //插入id... ，？用来防止SQL注入，
        executeUpdate("INSERT INTO user (user_id, password, name, phone, order_history) VALUES (?, ?, ?, ?, ?)",
                userId, password, name, phone, "[]");
    }

    // 删除用户功能
    private void deleteUser(JTable table) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "请先选择要删除的用户", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }// 获取用户信息
        String userId = (String) table.getValueAt(row, 0);
        String name = (String) table.getValueAt(row, 2);

        // 弹出确认框，显示用户名和ID
        int confirm = JOptionPane.showConfirmDialog(this, "确定要删除用户 " + name + "（ID：" + userId + "）吗？",
                "删除确认", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            // 执行删除用户的SQL语句
            executeUpdate("DELETE FROM user WHERE user_id = ?", userId);
        }
    }

    // 修改用户信息功能
    private void updateUserInfo(JTable table) {
        int row = table.getSelectedRow(); // 获取选中行号
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "请先选择要修改的用户", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }// 获取用户信息
        String userId = (String) table.getValueAt(row, 0);
        String currentName = (String) table.getValueAt(row, 2);
        String currentPhone = (String) table.getValueAt(row, 3);
        // 输入新信息
        String newName = JOptionPane.showInputDialog(this, "当前姓名：" + currentName + "\n请输入新姓名：", currentName);
        if (newName == null) return;
        String newPhone = JOptionPane.showInputDialog(this, "当前手机号：" + (currentPhone.isEmpty() ? "未设置" : currentPhone) + "\n请输入新手机号（可选）：", currentPhone);
        if (newPhone == null) newPhone = currentPhone;

        // 执行更新用户信息的SQL语句
        executeUpdate("UPDATE user SET name = ?, phone = ? WHERE user_id = ?", newName, newPhone, userId);
    }

    // 关闭数据库连接
    @Override
    public void dispose() {
        try {
            // 如果数据库连接
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        super.dispose(); // 调用父类的关闭方法
    }
}
