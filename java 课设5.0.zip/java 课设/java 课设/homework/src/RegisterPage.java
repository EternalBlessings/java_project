import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class RegisterPage {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField phoneField;
    private JRadioButton maleRadio;
    private JRadioButton femaleRadio;

    // 数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/power_rental_db?useSSL=false";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "yangpl1689";

    public RegisterPage() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("移动电源租赁系统 - 注册");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        // 主面板 - 左右分栏布局
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 0.4;
        gbc.weighty = 1.0;

        // 左侧品牌区
        JPanel brandPanel = createBrandPanel();
        mainPanel.add(brandPanel, gbc);

        // 右侧表单区
        gbc.weightx = 0.6;
        gbc.gridx = 1;
        JPanel formPanel = createFormPanel();
        mainPanel.add(formPanel, gbc);

        frame.setContentPane(mainPanel);
        frame.setVisible(true);
    }

    private JPanel createBrandPanel() {
        JPanel brandPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // 背景
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gradient = new GradientPaint(0, 0, new Color(100, 78, 221),
                        0, getHeight(), new Color(160, 85, 221));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                // 绘制右侧分割线
                g.setColor(new Color(230, 230, 230));
                g.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
            }
        };
        brandPanel.setBackground(new Color(245, 247, 250));
        brandPanel.setPreferredSize(new Dimension(400, 600));

        // 品牌Logo图片
        ImageIcon icon = null;
        try {
            icon = new ImageIcon(E:/AE/java 课设/java 课设/homework/user_picture/logos.png);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "图片加载失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            // 使用默认图标
            icon = new ImageIcon();
        }

        // 调整图片大小
        Image image = icon.getImage();
        if (image != null) {
            int newWidth = 180;
            int newHeight = 180;
            Image scaledImage = image.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            icon = new ImageIcon(scaledImage);
        }

        // 品牌名称
        JLabel brandLabel = new JLabel("PowerRental");
        brandLabel.setFont(new Font("微软雅黑", Font.BOLD, 28));
        brandLabel.setForeground(Color.WHITE);

        // 品牌标语
        JLabel sloganLabel = new JLabel("随时充电，随心而行");
        sloganLabel.setFont(new Font("微软雅黑", Font.PLAIN, 18));
        sloganLabel.setForeground(new Color(220, 220, 255));

        JLabel logoLabel = new JLabel(icon);
        logoLabel.setOpaque(false);
        JPanel logoPanel = new JPanel();
        logoPanel.setOpaque(false);
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.add(logoLabel);
        logoPanel.add(Box.createVerticalStrut(20));
        logoPanel.add(brandLabel);
        logoPanel.add(Box.createVerticalStrut(10));
        logoPanel.add(sloganLabel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.CENTER;
        brandPanel.add(logoPanel, gbc);

        return brandPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints formGbc = new GridBagConstraints();
        formGbc.insets = new Insets(10, 30, 10, 30);
        formGbc.anchor = GridBagConstraints.CENTER;
        formGbc.fill = GridBagConstraints.HORIZONTAL;

        // 标题
        formGbc.gridy = 0;
        JLabel titleLabel = new JLabel("注册");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 24));
        titleLabel.setForeground(new Color(50, 50, 50));
        formPanel.add(titleLabel, formGbc);

        // 用户名输入框
        formGbc.gridy = 1;
        JPanel usernamePanel = createInputPanel("👤", "请输入用户名");
        usernameField = (JTextField) usernamePanel.getComponent(1);
        formPanel.add(usernamePanel, formGbc);

        // 密码输入框
        formGbc.gridy = 2;
        String passwordIconPath = "E:/AE/java 课设/homework/user_picture/password.png";
        JPanel passwordPanel = createInputPanel(passwordIconPath, "请输入密码");
        passwordField = (JPasswordField) passwordPanel.getComponent(1);
        passwordField.setEchoChar('•');
        formPanel.add(passwordPanel, formGbc);

        // 确认密码输入框
        formGbc.gridy = 3;
        String confirmPasswordIconPath = "E:/AE/java 课设/homework/user_picture/password.png";
        JPanel confirmPasswordPanel = createInputPanel(confirmPasswordIconPath, "请确认密码");
        confirmPasswordField = (JPasswordField) confirmPasswordPanel.getComponent(1);
        confirmPasswordField.setEchoChar('•');
        formPanel.add(confirmPasswordPanel, formGbc);

        // 手机号输入框
        formGbc.gridy = 4;
        JPanel phonePanel = createInputPanel("📱", "请输入手机号");
        phoneField = (JTextField) phonePanel.getComponent(1);
        formPanel.add(phonePanel, formGbc);

        // 性别选择 - 确保使用类成员变量
        formGbc.gridy = 5;
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        genderPanel.setOpaque(false);

        JLabel genderLabel = new JLabel("性别:");
        genderLabel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        genderPanel.add(genderLabel);

        ButtonGroup genderGroup = new ButtonGroup();

        // 使用类成员变量并确保初始化
        maleRadio = new JRadioButton("男");
        maleRadio.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        maleRadio.setOpaque(false);
        maleRadio.setSelected(true);

        femaleRadio = new JRadioButton("女");
        femaleRadio.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        femaleRadio.setOpaque(false);

        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);

        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        formPanel.add(genderPanel, formGbc);

        // 注册按钮
        formGbc.gridy = 6;
        JButton registerButton = createStyledButton("注册", new Color(244, 67, 54));
        registerButton.addActionListener(e -> register());
        formPanel.add(registerButton, formGbc);

        // 登录入口
        formGbc.gridy = 7;
        JPanel loginPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        loginPanel.setOpaque(false);

        JLabel loginLabel = new JLabel("已有账号？");
        loginLabel.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        loginLabel.setForeground(new Color(150, 150, 150));
        loginPanel.add(loginLabel);

        JButton loginLink = new JButton("→ 登录");
        loginLink.setFont(new Font("微软雅黑", Font.BOLD, 12));
        loginLink.setForeground(new Color(76, 175, 80));
        loginLink.setBorderPainted(false);
        loginLink.setContentAreaFilled(false);
        loginLink.setFocusPainted(false);
        loginLink.addActionListener(e -> {
            frame.dispose();
            new LoginPage(null).setVisible(true);
        });
        loginPanel.add(loginLink);

        formPanel.add(loginPanel, formGbc);

        return formPanel;
    }




    private JPanel createInputPanel(String iconPath, String placeholder) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 247, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        panel.setPreferredSize(new Dimension(300, 45));
        // 使用图片路径创建图标
        JLabel iconLabel = new JLabel();
        if (iconPath != null && !iconPath.isEmpty()) {
            try {
                ImageIcon icon = new ImageIcon(iconPath);
                // 调整图片大小
                Image image = icon.getImage();
                Image scaledImage = image.getScaledInstance(24, 24, Image.SCALE_SMOOTH);
                icon = new ImageIcon(scaledImage);
                iconLabel.setIcon(icon);
            } catch (Exception e) {
                System.err.println("无法加载图标: " + e.getMessage());
                // 加载失败时使用默认图标
                iconLabel.setText("🔒");
                iconLabel.setFont(new Font("Arial", Font.PLAIN, 20));
            }
        } else {
            // 如果没有提供路径，使用默认图标
            iconLabel.setText("🔒");
            iconLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        }
        iconLabel.setPreferredSize(new Dimension(30, 30));

        JTextField textField = placeholder.equals("请输入密码") || placeholder.equals("请确认密码") ?
                new JPasswordField() : new JTextField();
        textField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        textField.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        textField.setOpaque(false);

        // 设置占位符文本
        if (!placeholder.isEmpty()) {
            textField.setText(placeholder);
            textField.setForeground(Color.GRAY);

            textField.addFocusListener(new java.awt.event.FocusAdapter() {
                public void focusGained(java.awt.event.FocusEvent evt) {
                    if (textField.getText().equals(placeholder)) {
                        textField.setText("");
                        textField.setForeground(Color.BLACK);
                    }
                }

                public void focusLost(java.awt.event.FocusEvent evt) {
                    if (textField.getText().isEmpty()) {
                        textField.setText(placeholder);
                        textField.setForeground(Color.GRAY);
                    }
                }
            });
        }

        panel.add(iconLabel, BorderLayout.WEST);
        panel.add(textField, BorderLayout.CENTER);

        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("微软雅黑", Font.BOLD, 16));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        button.setPreferredSize(new Dimension(300, 45));

        // 添加悬停效果
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }

    private void register() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String phone = phoneField.getText().trim();
        String gender = maleRadio.isSelected() ? "男" : "女";

        // 检查是否为占位符文本
        if (username.equals("请输入用户名") || password.equals("请输入密码") || confirmPassword.equals("请确认密码") || phone.equals("请输入手机号")) {
            JOptionPane.showMessageDialog(frame, "请输入完整的注册信息", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 检查用户名和密码是否为空
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "请输入完整的注册信息", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 检查两次输入的密码是否一致
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(frame, "两次输入的密码不一致", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 检查手机号格式是否正确
        if (!phone.matches("^1[3-9]\\d{9}$")) {
            JOptionPane.showMessageDialog(frame, "请输入有效的手机号码", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // 检查用户名是否已存在
            String checkSql = "SELECT id FROM users WHERE username = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
                pstmt.setString(1, username);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(frame, "该用户名已被注册，请选择其他用户名", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // 插入新用户信息
            String insertSql = "INSERT INTO users (username, password, phone, balance, is_admin, gender) VALUES (?, ?, ?, 100.00, FALSE, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                pstmt.setString(3, phone);
                pstmt.setString(4, gender);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(frame, "注册成功! 请登录", "成功", JOptionPane.INFORMATION_MESSAGE);
                frame.dispose();
                new LoginPage(null).setVisible(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "注册失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegisterPage());
    }
}
