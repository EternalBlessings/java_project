import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.File;

public class LoginPage extends JDialog {
    private JFrame parentFrame;
    private JTextField usernameField;
    private JPasswordField passwordField;

    // 数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/power_rental_db?useSSL=false";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "yangpl1689";

    public LoginPage(JFrame parent) {
        super(parent, "移动电源租赁系统 - 登录", true);
        this.parentFrame = parent;
        initialize();
    }

    private void initialize() {
        setSize(1000, 600);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // 主面板 - 左右分栏布局
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 0.4;
        gbc.weighty = 1.0;

        // 左侧品牌区 - 添加图片
        JPanel brandPanel = createBrandPanel();
        mainPanel.add(brandPanel, gbc);

        // 右侧表单区
        gbc.weightx = 0.6;
        gbc.gridx = 1;
        JPanel formPanel = createFormPanel();
        mainPanel.add(formPanel, gbc);

        setContentPane(mainPanel);
    }

    private JPanel createBrandPanel() {
        JPanel brandPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // 背景
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gradient = new GradientPaint(0, 0, new Color(56, 142, 60),
                        0, getHeight(), new Color(39, 174, 96));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());

                // 绘制右侧分割线
                g.setColor(new Color(200, 200, 200));
                g.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
            }
        };
        brandPanel.setPreferredSize(new Dimension(400, 600));

        // 品牌Logo图片 - 使用绝对路径加载
        ImageIcon icon = null;
        try {
            // 使用绝对路径加载图片
            String imagePath = "E:/AE/java 课设/homework/user_picture/logo177.png";
            File imageFile = new File(imagePath);
            if (imageFile.exists()) {
                icon = new ImageIcon(imagePath);
            } else {
                // 图片不存在时创建空白图标
                icon = new ImageIcon();
                System.err.println("Logo图片不存在: " + imagePath);
            }
        } catch (Exception e) {
            // 异常时创建空白图标
            icon = new ImageIcon();
            e.printStackTrace();
        }

        // 调整图片大小
        if (icon != null && icon.getImage() != null) {
            int newWidth = 180;
            int newHeight = 180;
            Image scaledImage = icon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            icon = new ImageIcon(scaledImage);
        }

        JLabel logoLabel = new JLabel(icon);
        logoLabel.setOpaque(false);

        // 品牌名称
        JLabel brandLabel = new JLabel("PowerRental");
        brandLabel.setFont(new Font("微软雅黑", Font.BOLD, 28));
        brandLabel.setForeground(Color.WHITE);

        // 品牌标语
        JLabel sloganLabel = new JLabel("随时充电，随心而行");
        sloganLabel.setFont(new Font("微软雅黑", Font.PLAIN, 18));
        sloganLabel.setForeground(new Color(220, 220, 255));

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setOpaque(false);
        contentPanel.add(logoLabel);
        contentPanel.add(Box.createVerticalStrut(20));
        contentPanel.add(brandLabel);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(sloganLabel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.CENTER;
        brandPanel.add(contentPanel, gbc);

        return brandPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints formGbc = new GridBagConstraints();
        formGbc.insets = new Insets(15, 40, 15, 40); // 增加边距
        formGbc.anchor = GridBagConstraints.CENTER;
        formGbc.fill = GridBagConstraints.HORIZONTAL;

        // 标题
        formGbc.gridy = 0;
        JLabel titleLabel = new JLabel("登录");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 28));
        titleLabel.setForeground(new Color(50, 50, 50));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        formPanel.add(titleLabel, formGbc);

        // 添加分隔线
        formGbc.gridy = 1;
        JSeparator separator = new JSeparator(SwingConstants.HORIZONTAL);
        separator.setForeground(new Color(220, 220, 220));
        separator.setPreferredSize(new Dimension(300, 2));
        formPanel.add(separator, formGbc);

        // 账号输入框
        formGbc.gridy = 2;
        JPanel usernamePanel = createInputPanel("👤", "请输入用户名");
        usernameField = (JTextField) usernamePanel.getComponent(1);
        formPanel.add(usernamePanel, formGbc);

        // 密码输入框
        formGbc.gridy = 3;
        JPanel passwordPanel = createInputPanel("🔒", "请输入密码");
        passwordField = (JPasswordField) passwordPanel.getComponent(1);
        passwordField.setEchoChar('•');
        formPanel.add(passwordPanel, formGbc);

        // 记住我复选框
        formGbc.gridy = 4;
        JCheckBox rememberCheckbox = new JCheckBox("记住我");
        rememberCheckbox.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        rememberCheckbox.setOpaque(false);
        formPanel.add(rememberCheckbox, formGbc);

        // 登录按钮
        formGbc.gridy = 5;
        JButton loginButton = createStyledButton("登录", new Color(76, 175, 80), 320, 45);
        loginButton.addActionListener(e -> login());
        formPanel.add(loginButton, formGbc);

        // 忘记密码链接
        formGbc.gridy = 6;
        JButton forgotPassword = new JButton("忘记密码?");
        forgotPassword.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        forgotPassword.setForeground(new Color(100, 100, 100));
        forgotPassword.setBorderPainted(false);
        forgotPassword.setContentAreaFilled(false);
        forgotPassword.setFocusPainted(false);
        forgotPassword.addActionListener(e -> showForgotPasswordDialog());
        formPanel.add(forgotPassword, formGbc);

        // 第三方登录标题
        formGbc.gridy = 7;
        JLabel socialLabel = new JLabel("第三方登录");
        socialLabel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        socialLabel.setForeground(new Color(150, 150, 150));
        socialLabel.setHorizontalAlignment(SwingConstants.CENTER);
        formPanel.add(socialLabel, formGbc);

        // 第三方登录按钮
        formGbc.gridy = 8;
        JPanel socialPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        socialPanel.setOpaque(false);

// 微信登录按钮 - 使用绝对路径
        String wechatIconPath = "E:/AE/java 课设/homework/user_picture/wx.png";
        JButton wechatButton = createSocialButton("微信", wechatIconPath);
        wechatButton.addActionListener(e -> showThirdPartyLoginMessage("微信"));
        socialPanel.add(wechatButton);

// QQ登录按钮 - 使用绝对路径
        String qqIconPath = "E:/AE/java 课设/homework/user_picture/qq.png";
        JButton qqButton = createSocialButton("QQ", qqIconPath);
        qqButton.addActionListener(e -> showThirdPartyLoginMessage("QQ"));
        socialPanel.add(qqButton);

        formPanel.add(socialPanel, formGbc);

        // 注册入口
        formGbc.gridy = 9;
        JPanel registerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        registerPanel.setOpaque(false);

        JLabel registerLabel = new JLabel("还没有账号？");
        registerLabel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        registerLabel.setForeground(new Color(150, 150, 150));
        registerPanel.add(registerLabel);

        JButton registerLink = new JButton("立即注册");
        registerLink.setFont(new Font("微软雅黑", Font.BOLD, 14));
        registerLink.setForeground(new Color(25, 118, 210));
        registerLink.setBorderPainted(false);
        registerLink.setContentAreaFilled(false);
        registerLink.setFocusPainted(false);
        registerLink.addActionListener(e -> showRegisterDialog());
        registerPanel.add(registerLink);

        formPanel.add(registerPanel, formGbc);

        return formPanel;
    }

    private JPanel createInputPanel(String iconText, String placeholder) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 247, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        panel.setPreferredSize(new Dimension(320, 50)); // 增加高度

        // 图标容器（增加内边距）
        JPanel iconPanel = new JPanel(new BorderLayout());
        iconPanel.setOpaque(false);
        iconPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));

        JLabel iconLabel = new JLabel(iconText);
        iconLabel.setFont(new Font("Arial", Font.PLAIN, 22)); // 增大图标
        iconLabel.setForeground(new Color(100, 100, 100));
        iconPanel.add(iconLabel, BorderLayout.CENTER);

        JTextField textField = placeholder.equals("请输入密码") ?
                new JPasswordField() : new JTextField();
        textField.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10)); // 增加内边距
        textField.setFont(new Font("微软雅黑", Font.PLAIN, 16)); // 增大字体
        textField.setOpaque(false);

        // 设置占位符文本
        if (!placeholder.isEmpty()) {
            textField.setText(placeholder);
            textField.setForeground(Color.GRAY);

            textField.addFocusListener(new java.awt.event.FocusAdapter() {
                public void focusGained(java.awt.event.FocusEvent evt) {
                    if (textField.getText().equals(placeholder)) {
                        textField.setText("");
                        textField.setForeground(Color.BLACK);
                    }
                }

                public void focusLost(java.awt.event.FocusEvent evt) {
                    if (textField.getText().isEmpty()) {
                        textField.setText(placeholder);
                        textField.setForeground(Color.GRAY);
                    }
                }
            });
        }

        panel.add(iconPanel, BorderLayout.WEST);
        panel.add(textField, BorderLayout.CENTER);

        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor, int width, int height) {
        JButton button = new JButton(text);
        button.setFont(new Font("微软雅黑", Font.BOLD, 18)); // 增大字体
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        button.setPreferredSize(new Dimension(width, height));

        // 添加悬停效果
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
                button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
                button.setCursor(Cursor.getDefaultCursor());
            }
        });

        return button;
    }

    private JButton createSocialButton(String platform, String iconPath) {
        JButton button = new JButton(platform);
        button.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        button.setBackground(new Color(240, 242, 245));
        button.setForeground(new Color(80, 80, 80));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
                BorderFactory.createEmptyBorder(8, 30, 8, 30)
        ));

        // 使用绝对路径加载图标
        try {
            File iconFile = new File(iconPath);
            if (iconFile.exists()) {
                ImageIcon icon = new ImageIcon(iconPath);
                if (icon.getImage() != null) {
                    Image scaledImage = icon.getImage().getScaledInstance(24, 24, Image.SCALE_SMOOTH);
                    button.setIcon(new ImageIcon(scaledImage));
                    button.setIconTextGap(10);
                    button.setHorizontalTextPosition(SwingConstants.LEFT);
                }
            } else {
                System.out.println("图标文件不存在: " + iconPath);
            }
        } catch (Exception e) {
            System.out.println("无法加载" + platform + "图标: " + e.getMessage());
        }

        // 添加悬停效果
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(230, 230, 230));
                button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(240, 242, 245));
                button.setCursor(Cursor.getDefaultCursor());
            }
        });

        return button;
    }

    private void login() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        // 检查是否为占位符文本
        if (username.equals("请输入用户名") || password.equals("请输入密码")) {
            JOptionPane.showMessageDialog(this, "请输入用户名和密码", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请输入用户名和密码", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT id, is_admin FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    int userId = rs.getInt("id");
                    boolean isAdmin = rs.getBoolean("is_admin");

                    // 关闭登录对话框
                    dispose();

                    // 如果有父窗口则销毁它
                    if (parentFrame != null) {
                        parentFrame.dispose();
                    }

                    // 打开主界面
                    PowerRentalSystem system = new PowerRentalSystem();
                    system.setCurrentUser(userId, username, isAdmin);
                } else {
                    JOptionPane.showMessageDialog(this, "用户名或密码错误", "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "登录失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showForgotPasswordDialog() {
        JDialog dialog = new JDialog(this, "忘记密码", true);
        dialog.setSize(400, 300);
        dialog.setLayout(new GridBagLayout());
        dialog.setLocationRelativeTo(this);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 20, 15, 20);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 标题
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("找回密码");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        dialog.add(titleLabel, gbc);

        // 分隔线
        gbc.gridy = 1;
        JSeparator separator = new JSeparator();
        dialog.add(separator, gbc);

        // 用户名
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        dialog.add(new JLabel("用户名:"), gbc);

        gbc.gridx = 1;
        JTextField usernameField = new JTextField();
        dialog.add(usernameField, gbc);

        // 手机号
        gbc.gridy = 3;
        gbc.gridx = 0;
        dialog.add(new JLabel("手机号:"), gbc);

        gbc.gridx = 1;
        JTextField phoneField = new JTextField();
        dialog.add(phoneField, gbc);

        // 验证码
        gbc.gridy = 4;
        gbc.gridx = 0;
        dialog.add(new JLabel("验证码:"), gbc);

        gbc.gridx = 1;
        JPanel verifyPanel = new JPanel(new BorderLayout());
        JTextField verifyField = new JTextField();
        JButton sendCodeButton = new JButton("发送验证码");
        sendCodeButton.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        sendCodeButton.addActionListener(e -> {
            String phone = phoneField.getText();
            if (phone.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "请输入手机号", "提示", JOptionPane.WARNING_MESSAGE);
                return;
            }
            // 模拟发送验证码
            JOptionPane.showMessageDialog(dialog, "验证码已发送到您的手机", "提示", JOptionPane.INFORMATION_MESSAGE);
        });

        verifyPanel.add(verifyField, BorderLayout.CENTER);
        verifyPanel.add(sendCodeButton, BorderLayout.EAST);
        dialog.add(verifyPanel, gbc);

        // 按钮
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton resetButton = new JButton("重置密码");
        resetButton.addActionListener(e -> {
            // 验证逻辑
            JOptionPane.showMessageDialog(dialog, "密码重置成功，请使用新密码登录", "成功", JOptionPane.INFORMATION_MESSAGE);
            dialog.dispose();
        });
        buttonPanel.add(resetButton);

        JButton cancelButton = new JButton("取消");
        cancelButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(cancelButton);

        dialog.add(buttonPanel, gbc);

        dialog.setVisible(true);
    }

    private void showThirdPartyLoginMessage(String platform) {
        JOptionPane.showMessageDialog(this, platform + "登录功能尚未实现", "提示", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showRegisterDialog() {
        // 关闭当前登录对话框
        dispose();

        // 打开注册页面，不传递参数
        new RegisterPage();
    }}

